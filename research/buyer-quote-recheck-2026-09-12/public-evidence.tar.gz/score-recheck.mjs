import fs from 'node:fs';
const root=new URL('.',import.meta.url);
const read=n=>JSON.parse(fs.readFileSync(new URL(n,root),'utf8'));
const rows=read('quotes.json'),menu=read('menu.snapshot'),manifest=read('manifest.snapshot');
function offers(r){try{return r?.headers?.['payment-required']?JSON.parse(Buffer.from(r.headers['payment-required'],'base64')).accepts:r?.body?.error?.data?.['x402/payment-required']?.accepts??[];}catch{return[];}}
const rails=o=>[...new Set(o.map(x=>x.network))].sort();
const comparisons=menu.items.map(item=>{
 const http=rows.find(r=>r.item===item.id&&r.door==='http'),mcp=rows.find(r=>r.item===item.id&&r.door==='mcp');
 const resource=manifest.resources.find(r=>new URL(r.resource).pathname==='/api/buy/'+item.id);
 const h=rails(offers(http)),m=rails(offers(mcp)),d=rails(resource?.accepts??[]);
 const both=!!h.length&&!!m.length;
 return {item:item.id,both_quoted:both,http:h,mcp:m,manifest:d,door_match:both&&JSON.stringify(h)===JSON.stringify(m),manifest_match:both&&JSON.stringify(h)===JSON.stringify(d),http_status:http?.status,mcp_code:mcp?.body?.error?.code};
});
const summary={at:new Date().toISOString(),requests:rows.length,comparable:comparisons.filter(r=>r.both_quoted).length,door_matching:comparisons.filter(r=>r.door_match).length,manifest_matching:comparisons.filter(r=>r.manifest_match).length,door_mismatches:comparisons.filter(r=>r.both_quoted&&!r.door_match),manifest_mismatches:comparisons.filter(r=>r.both_quoted&&!r.manifest_match),unquoted:comparisons.filter(r=>!r.both_quoted),payment_submitted:false,parser_correction:'The initial parser missed the namespaced MCP x402/payment-required field. This result derives from the retained raw responses, without new requests; no product failure is inferred from the initial empty parsed rail arrays.',comparisons};
fs.writeFileSync(new URL('summary.corrected.json',root),JSON.stringify(summary,null,2)+'\n');
console.log(JSON.stringify({...summary,comparisons:undefined},null,2));
