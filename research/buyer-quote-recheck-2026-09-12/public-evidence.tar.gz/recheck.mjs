import fs from 'node:fs';
const root=new URL('.',import.meta.url);
const read=n=>JSON.parse(fs.readFileSync(new URL(n+'.snapshot',root),'utf8'));
const menu=read('menu'),tools=read('mcp').result.tools,manifest=read('manifest');
const rows=[];
const save=()=>fs.writeFileSync(new URL('quotes.json',root),JSON.stringify(rows,null,2)+'\n');
function offers(row){
 const h=row.headers?.['payment-required'];
 if(h) return JSON.parse(Buffer.from(h,'base64').toString()).accepts??[];
 return row.body?.error?.data?.accepts??row.body?.result?.structuredContent?.accepts??[];
}
const tasks=menu.items.map(item=>async()=>{
 const tool=tools.find(t=>t.itemIds?.includes(item.id)||t.inputSchema?.properties?.item_id?.enum?.includes(item.id));
 const example=tool?.inputSchema?.examples?.find(e=>e.item_id===item.id);
 if(!example){rows.push({item:item.id,excluded:'No published example'});save();return;}
 const args=Object.fromEntries(Object.entries(example).filter(([k])=>k!=='item_id'));
 for(const door of ['http','mcp']){
  const url=new URL(door==='http'?'/api/buy/'+item.id:'/mcp','https://scvd.store');
  if(door==='http')for(const [k,v]of Object.entries(args))url.searchParams.set(k,String(v));
  const init=door==='http'?{}:{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:item.id,method:'tools/call',params:{name:tool.name,arguments:example}})};
  const row={item:item.id,door,args,url:String(url),sent_at:new Date().toISOString(),payment_submitted:false};
  try{const response=await fetch(url,{...init,redirect:'manual',signal:AbortSignal.timeout(30000)});row.status=response.status;row.headers=Object.fromEntries(response.headers);row.body=await response.json();row.rails=[...new Set(offers(row).map(o=>o.network))].sort();}
  catch(e){row.instrument_error=String(e);}
  row.received_at=new Date().toISOString();rows.push(row);save();
 }
});
let next=0;await Promise.all(Array.from({length:2},async()=>{while(next<tasks.length)await tasks[next++]();}));
const comparisons=menu.items.map(item=>{
 const http=rows.find(r=>r.item===item.id&&r.door==='http'),mcp=rows.find(r=>r.item===item.id&&r.door==='mcp');
 const resource=manifest.resources.find(r=>new URL(r.resource).pathname==='/api/buy/'+item.id);
 const declared=[...new Set(resource?.accepts?.map(o=>o.network)??[])].sort();
 const bothQuoted=!!http?.rails?.length&&!!mcp?.rails?.length;
 return {item:item.id,both_quoted:bothQuoted,http:http?.rails,mcp:mcp?.rails,manifest:declared,match:bothQuoted&&JSON.stringify(http.rails)===JSON.stringify(mcp.rails)&&JSON.stringify(http.rails)===JSON.stringify(declared)};
});
const summary={at:new Date().toISOString(),requests:rows.length,comparable:comparisons.filter(r=>r.both_quoted).length,matching:comparisons.filter(r=>r.match).length,mismatches:comparisons.filter(r=>r.both_quoted&&!r.match),unquoted:comparisons.filter(r=>!r.both_quoted),payment_submitted:false,comparisons};
fs.writeFileSync(new URL('summary.json',root),JSON.stringify(summary,null,2)+'\n');
console.log(JSON.stringify({...summary,comparisons:undefined}));
