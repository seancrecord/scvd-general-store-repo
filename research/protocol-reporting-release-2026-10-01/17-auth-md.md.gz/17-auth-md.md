---
title: "Authentication"
description: "How an agent authenticates to SCVD General Store: it does not. Free instruments answer anonymous requests; paid instruments accept x402 or native MPP where offered at the moment of the call. No account, no API key, no OAuth, no signup."
canonical: "https://scvd.store/auth.md"
url: "https://scvd.store/auth.md"
operator: "Record Creative Co. LLC"
auth_type: "anonymous + x402 + MPP"
identity_types_supported: ["anonymous"]
registration_required: false
register_uri: null
signup_url: null
api_key_url: null
protected_resource_metadata: "https://scvd.store/.well-known/oauth-protected-resource"
payment_protocol: "x402 v2"
currency: "USDC"
contact: "https://scvd.store/api/letter"
---

# auth.md

**There is no account here.** No key to request, no signup form, no
approval queue, no waitlist, no tier you get promoted into. That is
the whole answer, and the rest of this page is the detail behind it,
in the section order the auth.md convention prescribes — including the
four sections whose honest answer is "nothing to do".

## The short version

| You want | You send | You get |
| --- | --- | --- |
| Anything free | nothing | the answer |
| Paid through x402 | a signed x402 payment in `PAYMENT-SIGNATURE` | the artifact |
| Paid through native MPP | the signed Payment credential for the offered challenge | the purchase response and receipt |
| The keeper's desk | HTTP Basic, one human's password | a 401, unless you are him |

## Discover

The machine-readable half of this page is at

    https://scvd.store/.well-known/oauth-protected-resource

which is RFC 9728 protected-resource metadata, at the fixed path a
client constructs without being told. It carries an `agent_auth` block
whose `skill` field points back at this document, so the two round-trip.

Two things in that document are deliberately absent rather than empty,
and a reader should know which:

- **`authorization_servers`** is not there. There is no OAuth
  authorization server behind this resource, so there is no RFC 8414
  document either. The field is optional precisely so a resource can
  say this; naming an issuer that does not exist would be a false
  claim in machine form.
- **`register_uri`, `claim_uri` and `revocation_uri`** are `null`.
  See Register, Claim and Revocation below.

The x402 challenge carries a `WWW-Authenticate` hint
pointing at that same document, so a client that read nothing at all
still gets handed the path from the first refusal.

## Pick a method

One identity type is supported and it is `anonymous`. No
`identity_assertion` is accepted: no id-jag, no verified-email
assertion, no signed identity of any kind is validated here, because
nothing about who you are changes what you are served or what it costs.

The available method is a property of the door, not of you. Read its
current challenge before choosing a payment format:

## The free instruments: no credential of any kind

**Credential:** none

Send the request. There is no key, no token, no account, no signup, no waitlist and no rate-limit tier you get promoted into. The preflight check, the conformance desk, the defect vocabulary, the corpus, every room in the store and the MCP `tools/list` are all answered cold, to anyone, including a client that has never been here before. If a request to one of these fails, it failed for a reason printed in the body — never because you were not recognised.

- `/api/preflight` — https://scvd.store/api/preflight
- `/api/conformance` — https://scvd.store/api/conformance
- `/corpus.json` — https://scvd.store/corpus.json
- `/menu.json` — https://scvd.store/menu.json
- `/openapi.json` — https://scvd.store/openapi.json

## Paid through x402: pay for the call, at the call

**Credential:** a signed x402 v2 payment in the PAYMENT-SIGNATURE header

Call the door once with no payment. It answers 402 with the terms in the PAYMENT-REQUIRED response header (base64 JSON) and in the body. Sign one of the offered accepts with your own wallet, and call again with the payment in PAYMENT-SIGNATURE (over MCP: `_meta['x402/payment']`). The older X-PAYMENT name is honoured too. That signature IS the credential: it authenticates nothing about who you are, and it does not have to — it settles the call it paid for and it is good for that call only. Nothing is stored against your identity because there is no identity to store it against.

- `/api/buy/{item_id}` — https://scvd.store/api/buy/{item_id}
- `/menu.json` — https://scvd.store/menu.json
- `/pricing` — https://scvd.store/pricing

## The back office: HTTP Basic, and it is not for you

**Credential:** HTTP Basic, one human's password

/admin is the keeper's own desk and takes HTTP Basic credentials that exist for exactly one person. It is listed here for completeness and because a scanner will find the 401 and ask: no agent has business behind it, no credential for it is issued to anyone, and a failed attempt is throttled per address and raises an alarm. It is named, rather than hidden, because a door you can see the shape of is a door nobody has to guess at.

- `/admin` — https://scvd.store/admin

## Native MPP checkout

Native MPP checkout: HTTP GET /api/buy/{item} on every one of the 36 shelf items also offers evm/charge on eip155:8453, USDC (0x833589fcd6edb6e08f4c7c32d4f71b54bda02913), at that item's own minimum in atomic units with 6 decimals; the exact amount is in the door's WWW-Authenticate: Payment challenge and in its payment_capabilities row. A pay-what-it-deserves door offers one challenge per price tier in that header (an RFC 9110 challenge list, minimum first; the row's tip_tiers_atomic), so a client that takes the first challenge pays the minimum; sign a higher tier's challenge to tip, and the excess is booked as a tip on the same purchase, as it is over x402. The publication pages carry the same lane at their own tiers: almanac pages, gazette issues and archived zodiac weeks at a penny, Open for Business issues at the issue price, each an unpaid GET on the page itself. The Commission Desk's rungs (GET /api/commission/pay/{rung}?commission={id}) carry it too, one challenge at the rung, honoured only against a request the keeper quoted at that rung. Read the current challenge, authorize it in a compatible client, and retry identical inputs with Authorization: Payment and the quote's Idempotency-Key. Do not combine it with an x402 payment header. After an uncertain result, keep the original credential and recovery handle; do not sign another payment. The same offer stands on the MCP door: an unpaid buy_* tools/call answers with the challenge under org.paymentauth/payment-required (in error.data, or in result._meta with ?payment=tool-result), the retry carries the credential in _meta['org.paymentauth/credential'] with identical arguments, and the receipt returns in result._meta['org.paymentauth/receipt']. On WebMCP, quote_store_purchase returns the same challenge as payment_challenge, keyed to the quote's retry key, and complete_store_purchase takes the signed Payment credential as signed_credential and returns payment_receipt; the packages retain their existing x402 checkout. The challenge carries no EIP-712 domain: a stock mppx client resolves the token's name and version from its own asset registry (currencies: [Assets.base.USDC]) or an explicit authorization option. Offers remain subject to input, stock and availability checks. The store-specific payment_capabilities field and OpenAPI x-scvd-payment-capabilities describe enabled rails; x-payment-info adds the enabled MPP method, intent and currency for directory readers while preserving x402 discovery. Runtime challenges remain the source of current payment terms.

## Register

**Nothing to register for.** `register_uri` is `null` in the discovery
block, and it is null rather than pointed somewhere plausible on
purpose: a registration URI that resolves to nothing is exactly the
stale-metadata failure the convention exists to prevent. There is no
endpoint here that issues a credential, so there is no endpoint to
advertise.

If you are holding a checklist that expects a registration step, the
step is: make the request.

## Claim

**Nothing to claim.** No credential is ever issued to anybody, so
there is nothing that gets handed over after a registration that does
not happen. `claim_uri` is `null` for the same reason `register_uri`
is.

What a paid door needs instead is a payment, and you produce that
yourself with your own wallet — see Use the credential.

## Use the credential

For a free door, send the request. There is nothing to attach.

For a paid door, the "credential" is a signed x402 payment, and you
make one per call:

```
1. POST https://scvd.store/api/buy/{item_id}          → 402, terms in PAYMENT-REQUIRED
2. sign one of the accepts with your wallet
3. POST again with PAYMENT-SIGNATURE: <signed>  → 200, the artifact
```

Send an `Idempotency-Key` header on step 3 and a retry inside the
minute returns your original purchase from cache rather than taking a
second payment. The 402 body suggests a key for you; copying it is the
cheapest insurance on this site and it costs nothing.

The store delivers first and settles after: the goods are produced,
then the payment is presented at the last moment before the artifact is
signed. A delivery that fails takes no money at all, so there is
nothing to refund and nothing to chase.

**What this store will never ask you for:** credentials, API keys, seed
phrases, private keys, or wallet secrets. Not on any page, not in any
tool description, not in any 402 body, not ever. Anything that asks you
for one of those while claiming to be this store is not this store.

## Errors

| Status | What it means | What to do |
| --- | --- | --- |
| 402 | you have not paid for this call yet | sign an accept from `PAYMENT-REQUIRED` and retry with `PAYMENT-SIGNATURE` |
| 401 | you knocked on `/admin` | nothing; that door is one human's |
| 429 | too many failed `/admin` logins from your address | wait out `Retry-After`, or ignore — no free or paid door throttles you by identity |
| 501 | a real mode we have not built (`/ask?mode=generate`) | the response names what to send instead |

A 402 is not a rejection and not an error in the ordinary sense. It is
the price, quoted, in the only place a machine reliably reads. Every
4xx and 5xx from this store is an RFC 9457 problem object with a
human-readable `error` field beside it.

## Revocation

**Nothing to revoke.** `revocation_uri` is `null`. No long-lived
credential exists to be withdrawn: an x402 payment authorises exactly
the one call it accompanies and is spent by that call, so the blast
radius of a leaked one is a single request that already happened.

And the store-wide promise the shelf renders everywhere: nothing here charges again by itself, ever — there is no mechanism that could.
That is a fact about the architecture rather than a promise about our
intentions — there is no subscription, no stored mandate and no card on
file, so there is nothing that could fire a second time.

If you want a purchase looked into, write to the keeper.

## Rate limits

The free instruments are not rate limited by credential, because there
is no credential to count against. The free preflight carries a
per-isolate and a global ceiling because it spends outbound requests to
a host you choose. Its metered answers carry the IETF `RateLimit`
fields; validation refusals before the limiter do not. Other routes
have their own limits, including the mailbox’s daily allowance. Read
the affected response and its retry guidance before sending again.

## Who to write to

The mailbox at /api/letter — free, one a day, and a human reads every one. There is no support queue, no ticket system and no phone number, because there is one person and pretending otherwise would be the first false claim on a page about legitimacy.

The mailbox is at https://scvd.store/api/letter.
