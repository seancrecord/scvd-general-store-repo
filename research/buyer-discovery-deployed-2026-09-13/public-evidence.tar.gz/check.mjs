import fs from 'node:fs';
import crypto from 'node:crypto';
const root = new URL('.', import.meta.url);
const calls = [];
async function capture(name, path, payload) {
  const url = new URL(path, 'https://scvd.store');
  const row = { name, url: String(url), method: payload ? 'POST' : 'GET', sent_at: new Date().toISOString(), payment_submitted: false, ...(payload ? { request_body: payload } : {}) };
  try {
    const res = await fetch(url, { method: row.method, redirect: 'manual', signal: AbortSignal.timeout(20000),
      headers: { 'User-Agent': 'scvd-buyer-audit/1.0 (unsigned discovery repair recheck)', ...(payload ? { 'Content-Type': 'application/json' } : {}) },
      ...(payload ? { body: JSON.stringify(payload) } : {}) });
    const raw = await res.text();
    fs.writeFileSync(new URL(name + '.body', root), raw);
    Object.assign(row, { status: res.status, headers: Object.fromEntries(res.headers), body_file: name + '.body', sha256: crypto.createHash('sha256').update(raw).digest('hex') });
    try { row.body = JSON.parse(raw); } catch { row.text = raw; }
  } catch (err) { row.instrument_error = String(err); }
  row.received_at = new Date().toISOString();
  calls.push(row);
  fs.writeFileSync(new URL('requests.json', root), JSON.stringify(calls, null, 2) + '\n');
  return row;
}
const llms = await capture('llms', '/llms.txt');
const alias = await capture('keys-alias', '/keys');
const keys = await capture('signing-key', '/.well-known/scvd-signing-key');
const mcp = await capture('mcp-tools', '/mcp', { jsonrpc: '2.0', id: 'list', method: 'tools/list', params: {} });
const checks = [];
for (const id of ['attestation_bundle', 'bitcoin_anchor']) {
  const tool = mcp.body?.result?.tools?.find(t => t.inputSchema?.examples?.some(e => e.item_id === id));
  const example = tool?.inputSchema?.examples?.find(e => e.item_id === id);
  if (!example) { checks.push({ item: id, quoted: false, reason: 'No published example found' }); continue; }
  const httpUrl = new URL('/api/buy/' + id, 'https://scvd.store');
  for (const [k, v] of Object.entries(example)) if (k !== 'item_id') httpUrl.searchParams.set(k, String(v));
  const http = await capture(id + '-http', httpUrl);
  const rpc = await capture(id + '-mcp', '/mcp', { jsonrpc: '2.0', id, method: 'tools/call', params: { name: tool.name, arguments: example } });
  const httpOffers = http.headers?.['payment-required'] ? JSON.parse(Buffer.from(http.headers['payment-required'], 'base64')).accepts : http.body?.accepts;
  const rpcOffers = rpc.body?.error?.data?.['x402/payment-required']?.accepts;
  const rails = offers => [...new Set((offers ?? []).map(o => o.network))].sort();
  checks.push({ item: id, example, http_status: http.status, mcp_http_status: rpc.status, mcp_code: rpc.body?.error?.code,
    http_rails: rails(httpOffers), mcp_rails: rails(rpcOffers), quoted: http.status === 402 && rpc.body?.error?.code === 402 && !!rpcOffers?.length,
    matching_rails: JSON.stringify(rails(httpOffers)) === JSON.stringify(rails(rpcOffers)) });
}
const result = { at: new Date().toISOString(), scope: 'Published bundle and anchor examples over HTTP and MCP, plus key-registry discovery; unsigned quotes only', requests: calls.length, payment_submitted: false,
  alias: { status: alias.status, location: alias.headers?.location }, canonical_key_status: keys.status,
  llms_names_canonical_key: llms.text?.includes('/.well-known/scvd-signing-key') ?? false, checks };
fs.writeFileSync(new URL('summary.json', root), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result));
